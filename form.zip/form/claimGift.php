<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <div class=" underlayImg p-5">
        <div class="card">
           <div class="card-title">
            <h2 >Claim your Free Gift</h2>
            <p>To claim your gift, please fill the information below</p>
           </div>
            <div class="claimInfo d-flex flex-column"  id="myForm">
                 <input type="text" placeholder="Name" id="name" class="p-4 my-2 borderSet">
                 <input type="text" placeholder="Phone" id="phone" class="p-4 my-2 borderSet">
                 <input type="email" placeholder="Email" id="email" class="p-4 my-2 borderSet">
                 <div class="selectOpt p-2 my-2 borderSet">
                    <p>Where did you find us ?</p>
                    <label class="fillbox mx-2">Existing Customer
                        <input type="checkbox" name="findUs" value="Existing Customer" >
                        <span class="checkmark"></span>
                      </label>
                      <label class="fillbox mx-2">Market
                        <input type="checkbox" name="findUs" value="Market" >
                        <span class="checkmark"></span>
                      </label>
                      <label class="fillbox mx-2">Social Media
                        <input type="checkbox" name="findUs" value="Social Media" >
                        <span class="checkmark"></span>
                      </label>
                  <label class="fillbox mx-2">Word of Mouth
                        <input type="checkbox" name="findUs" value="Word of Mouth">
                        <span class="checkmark"></span>
                      </label>
                 </div>

                 <div class="selectOpt p-2 my-2 borderSet">
                    <p>
                        What are you looking for-
                    </p>
                    <label class="fillbox mx-2">Living Room Furniture
                        <input type="checkbox"  name="lookingFor" value="Living Room Furniture">
                        <span class="checkmark"></span>
                      </label>
                      <label class="fillbox mx-2" >Dining Room Furniture
                        <input type="checkbox" name="lookingFor" value="Dining Room Furniture">
                        <span class="checkmark"></span>
                      </label>
                      <label class="fillbox mx-2">Bedroom Furniture
                        <input type="checkbox" name="lookingFor" value="Bedroom Furniture">
                        <span class="checkmark"></span>
                      </label>
                  <label class="fillbox mx-2">Accessiores
                        <input type="checkbox" name="lookingFor" value="Accessiores" >
                        <span class="checkmark"></span>
                      </label>
                 </div>

                 <select class=" p-4 my-2 borderSet " id="choices" >
                    <option value = " " selected>Attended by-</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                  </select>
                  
                   <textarea id="body"  class="my-2 borderSet"  placeholder="Let us know you suggestion ..." ></textarea>
                   <div class="d-flex justify-content-end my-4">
                   <button  class="px-3 py-1 bg-dark text-white border-0" id="submit" onclick="submitForm()">Submit</button>
                   </div>
                  
              </div>
            <h4 class="sent-notification"></h4>
        </div>
    </div>
    
   

    <script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>  
	<script type="text/javascript">
    function submitForm(){
      

      var findUs = [];  
      $('input[name="findUs"]').each(function(){  
          if($(this).is(":checked"))  
          {  
            findUs.push($(this).val());  
          }  
      });  
      findUs = findUs.toString();
    

      var lookingFor = [];  
      $('input[name="lookingFor"]').each(function(){  
          if($(this).is(":checked"))  
          {  
            lookingFor.push($(this).val());  
          }  
      });  
      lookingFor = lookingFor.toString();
      var no=1;//let say it.
      var choiceOption = $('#choices').val();
      console.log(choiceOption);
        var name = $("#name").val();
        var phone = $("#phone").val();
        var email = $("#email").val();
        var body = $("#body").val();
        alert(name);


      $('.borderSet').css('border', '2px solid #000');
      if(name == ''){
        $("#name").css('border', '2px solid red');
      }
      if(email == ''){
        $("#email").css('border', '2px solid red');
      }
      if(phone == ''){
        $("#phone").css('border', '2px solid red');
      }
      if(findUs == ''){
        $("#selectOpt").css('border', '2px solid red');
      }
      if(lookingFor == ''){
        $("#selectOpt").css('border', '2px solid red');
      }
      if(name != '' && phone != '' ){
        $.ajax({
            url: 'sendMail.php',
            type: 'POST',
            dataType: 'json',
            data: {
                name: name,
                phone: phone,
                email: email,
                findUs: findUs,
                lookingFor: lookingFor,
                choiceOption: choiceOption,
                body: body
            }, success: function (response) { 
              if(response.status == "success"){
                alert('do');
              }else{
                alert('ff');
              }
            }
        });
      }
    }
    
    </script>

</body>

</html>