<?php
use PHPMailer\PHPMailer\PHPMailer;

if(isset($_POST['name'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $findUs = $_POST['findUs'];
    $lookingFor = $_POST['lookingFor'];
    $choiceOption = $_POST['choiceOption'];
    $body = $_POST['body'];

    // require_once "PHPMailer/PHPMailer.php";
    // require_once "PHPMailer/SMTP.php";
    // require_once "PHPMailer/Exception.php";

    // $mail = new PHPMailer();

    // //smtp settings
    // $mail->isSMTP();
    // $mail->Host = "mail.techiesquad.in";
    // $mail->SMTPAuth = true;
    // $mail->Username = "amit@techiesquad.in";
    // $mail->Password = 'Amit@4159';
    // $mail->Port = 465;
    // $mail->SMTPSecure = "ssl";
    // $mail->Mailer   = "smtp";

    // //email settings
    // $mail->isHTML(true);
    // $mail->setFrom($email, $name);
    // $mail->addAddress("mail.techiesquad.in");
    // $mail->Subject = ("$email");
    // $mail->Body = $body;

    // if($mail->send()){
        $status = "success";
        $response = "Email is sent!";
    // }
    // else
    // {
    //     $status = "failed";
    //     $response = "Something is wrong: <br>" . $mail->ErrorInfo;
    // }

    $result = ["status" => $status, "response" => $response];
    echo json_encode($result);
    
}

?>
      